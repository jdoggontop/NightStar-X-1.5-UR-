                                                                                                                                                                                                                                                                                                              
--        CCCCCCCCCCCCC                                            hhhhhhh                                                          XXXXXXX       XXXXXXX
--     CCC::::::::::::C                                            h:::::h                                                          X:::::X       X:::::X
--   CC:::::::::::::::C                                            h:::::h                                                          X:::::X       X:::::X
--  C:::::CCCCCCCC::::C                                            h:::::h                                                          X::::::X     X::::::X
-- C:::::C       CCCCCCyyyyyyy           yyyyyyyppppp   ppppppppp   h::::h hhhhh           eeeeeeeeeeee    rrrrr   rrrrrrrrr        XXX:::::X   X:::::XXX
--C:::::C               y:::::y         y:::::y p::::ppp:::::::::p  h::::hh:::::hhh      ee::::::::::::ee  r::::rrr:::::::::r          X:::::X X:::::X   
--C:::::C                y:::::y       y:::::y  p:::::::::::::::::p h::::::::::::::hh   e::::::eeeee:::::eer:::::::::::::::::r          X:::::X:::::X    
--C:::::C                 y:::::y     y:::::y   pp::::::ppppp::::::ph:::::::hhh::::::h e::::::e     e:::::err::::::rrrrr::::::r          X:::::::::X     
--C:::::C                  y:::::y   y:::::y     p:::::p     p:::::ph::::::h   h::::::he:::::::eeeee::::::e r:::::r     r:::::r          X:::::::::X     
--C:::::C                   y:::::y y:::::y      p:::::p     p:::::ph:::::h     h:::::he:::::::::::::::::e  r:::::r     rrrrrrr         X:::::X:::::X    
--C:::::C                    y:::::y:::::y       p:::::p     p:::::ph:::::h     h:::::he::::::eeeeeeeeeee   r:::::r                    X:::::X X:::::X   
-- C:::::C       CCCCCC       y:::::::::y        p:::::p    p::::::ph:::::h     h:::::he:::::::e            r:::::r                 XXX:::::X   X:::::XXX
--  C:::::CCCCCCCC::::C        y:::::::y         p:::::ppppp:::::::ph:::::h     h:::::he::::::::e           r:::::r                 X::::::X     X::::::X
--   CC:::::::::::::::C         y:::::y          p::::::::::::::::p h:::::h     h:::::h e::::::::eeeeeeee   r:::::r                 X:::::X       X:::::X
--    CCC::::::::::::C        y:::::y           p::::::::::::::pp  h:::::h     h:::::h  ee:::::::::::::e   r:::::r                 X:::::X       X:::::X
--        CCCCCCCCCCCCC       y:::::y            p::::::pppppppp    hhhhhhh     hhhhhhh    eeeeeeeeeeeeee   rrrrrrr                 XXXXXXX       XXXXXXX
--                           y:::::y             p:::::p                                                                                                 
--                          y:::::y              p:::::p                                                                                                 
--                         y:::::y              p:::::::p                                                                                                
--                        y:::::y               p:::::::p                                                                                                
--                       yyyyyyy                p:::::::p                                                                                                
--                                              ppppppppp                                                                                                
                                                                                                                                                       
--[[
("Runs Smoothly Because of Iron Brew Epic Gamer c;")
("Heh trying to crack my hub hehe fuck off I obfuscate the scripts I made")
]]

loadstring(game:HttpGet(('https://pastebin.com/raw/twBxiUzz'),true))()