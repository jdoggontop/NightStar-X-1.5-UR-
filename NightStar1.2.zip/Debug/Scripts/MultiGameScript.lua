--[[

Games:

-Anime Fighting Simulator
-Arsenal
-Big Paintball

--]]


loadstring(game:HttpGet("https://pastebin.com/raw/cPek9wpE", true))()
