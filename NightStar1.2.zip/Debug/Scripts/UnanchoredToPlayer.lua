loadstring(game:HttpGet("https://pastebin.com/raw/y2yFfXw3", true))()
